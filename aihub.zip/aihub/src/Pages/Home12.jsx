
import Contact from '../Components/Contact/Contact';
import Department from '../Components/Department/Department';
import About from '../Components/About/About';
import Iconbox from '../Components/Iconbox/Iconbox';
import TestimonialSlider from '../Components/Slider/TestimonialSlider';
import Accordion from '../Components/Accordion/Accordion';

import Hero12 from '../Components/Hero/Hero12';


const heroData = {
  bgImg: 'images/hero-bg.jpg',
  bgShape: 'shape/hero-shape.png',
  sliderImages: [
    {
      img: 'images/hero-img.png',
    },
    {
      img: 'images/img22.png',
    },
   
  ],
  title: ['Crutches', 'Laboratory', 'Cardiology', 'Dentist', 'Neurology'],
};

const iconboxData = [
  {
    bg: 'purple',
    icon: 'icons/icon1.svg',
    title: 'Master Nursing Skills',
    subTitle:
      'Advance guidance to perfect your expertise.',
  },
  {
    bg: 'green',
    icon: 'icons/icon-3.jpeg',
    title: 'Exam Prep Made Easy',
    subTitle:
      'AI-driven tools for confident success.',
  },
  {
    bg: 'red',
    icon: 'icons/icon2.svg',
    title: '24/7 Smart Support',
    subTitle:
      'Guidance from AI and a 3D avatar nurse.',
  },
];

const aboutData = {
  title:
    'AI-Powered Platform to Accelerate Your Learning and Skill Development',
  subTitle:
    '  Our platform harnesses the power of AI to deliver tailored guidance and learning resources.With personalized insights and adaptive tools, we help you improve your skills and achieve success efficiently. Experience a smarter, more effective way to learn and grow with AI at the core of your journey.',

  avater: {
    img: 'images/avatar1.png',
    name: 'David',
    designation: 'Founder & Director',
  },
  timeTable: [
    {
      day: 'Provide AI-driven personalized guidence',
    },
    {
      day: 'Deliver real-time feedback and insights',
    },
    {
      day: 'Support efficient goal achievement',
    },
    {
      day: 'Offer a seamless learning experience',
    },
    
  ],
  contact: 'Nurse AI Hub',
};


const testimonialData = [
  {
    img: 'images/avatar2.png',
    name: 'Dr. Alex Carter',
    designation: 'Medical Consultant',
    subTitle:
      "AI is revolutionizing medical exam preparation, offering precise, customized support to help students succeed and improve patient care.",
  },
  {
    img: 'images/avatar3.png',
    name: 'Sarah Mitchell',
    designation: 'Clinical Training Specialist',
    subTitle:
      "AI is reshaping the way we prepare for medical exams, offering tailored learning paths that maximize understanding and boost exam success.",
  },
  {
    img: 'images/avatar4.png',
    name: 'John Davis',
    designation: 'Educational Technology Specialist',
    subTitle:
      "With AI-powered tools, we can provide a smarter approach to learning, enabling individuals to efficiently prepare for exams and enhance their professional skills.",
  },
 
];
const faqData = {
  title: 'Just Answer the Questions',
  img: 'images/faq-img.png',
  bgImg: 'shape/faq-bg.svg',
  faqItems: [
    {
      title: 'What is AI-powered health analysis?',
      content: `AI-powered health analysis uses advanced algorithms to process and interpret test results, providing more personalized, accurate, and efficient insights to help detect health conditions early and suggest preventive measures.`,
    },
    {
      title: 'How does AI improve medical test results?',
      content: `AI improves medical test results by analyzing large datasets with high accuracy and identifying patterns that might be missed by humans.`,
    },
    {
      title: 'Is AI safe to use for medical testing?',
      content: 'AI is safe for medical testing when implemented with strict regulatory compliance and ethical guidelines.',
    },
    {
      title: 'Can AI help with personalized health recommendations?',
      content: `AI assists in providing personalized health recommendations by analyzing individual health data and tailoring solutions accordingly.`,
    },
    {
      title: 'Can AI help with personalized health recommendations?',
      content: `AI assists in providing personalized health recommendations by analyzing individual health data and tailoring solutions accordingly.`,
    },
  ],
};






const Home12 = () => {
  return (
    <>
      <Hero12 data={heroData} />
      <Iconbox data={iconboxData} />
      <About data={aboutData} />
      <Department />
      <hr />
      <TestimonialSlider data={testimonialData} />
     
      <Accordion data={faqData} />
      <Contact />
      
    </>
  );
};

export default Home12;
