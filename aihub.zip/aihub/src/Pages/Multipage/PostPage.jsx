import React from 'react'
import MultiplePageHeading from '../../Components/Hero/MultiplePageHeading'

const heroData = {
  bgImg: `/images/hero-bg6.jpg`,
  title: `Our Latest News`,
  subTitle: `Gate all update news here`
}


const PostPage = () => {
  return (
    <>
      <MultiplePageHeading {...heroData} />
    </>
  )
}

export default PostPage
